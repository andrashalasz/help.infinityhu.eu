<?php
/**
 * admin_pages2.php - Word import, Fordítás, Képernyők, Képek, Felhasználók, Beállítások.
 */
declare(strict_types=1);

// ============================================================ WORD IMPORT
function page_import(PDO $db, array $cfg, string $lang, int $importId, array $counts): void
{
    $import = null;
    $items  = [];
    if ($importId > 0) {
        $st = $db->prepare('SELECT i.*, u.display_name FROM help_import i LEFT JOIN help_user u ON u.id = i.uploaded_by WHERE i.id = ?');
        $st->execute([$importId]);
        $import = $st->fetch() ?: null;
        if ($import) {
            $lang = (string)$import['lang'];
            $st = $db->prepare('SELECT it.*, a.plain_text AS cur_plain, a.title AS cur_title
                                  FROM help_import_item it
                                  LEFT JOIN help_article a ON a.id = it.article_id
                                 WHERE it.import_id = ? ORDER BY it.seq');
            $st->execute([$importId]);
            $items = $st->fetchAll();
        }
    }

    $recent = $db->query('SELECT i.*, u.display_name FROM help_import i LEFT JOIN help_user u ON u.id = i.uploaded_by
                       ORDER BY i.uploaded_at DESC LIMIT 10')->fetchAll();

    admin_head('Word import', 'import', $counts);
    ?>
<div class="page">
  <h1 class="pt"><?= h(t('Word import')) ?></h1>
  <p class="lead">
    <?= t('import.bevezeto') ?>
  </p>
  <?= flash_render() ?>

  <div class="panel" style="margin-bottom:16px">
    <div class="panel__h"><h2><?= h(t('Új dokumentum betöltése')) ?></h2></div>
    <div class="panel__b">
      <form method="post" action="<?= h(admin_url()) ?>" enctype="multipart/form-data">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="import.upload">
        <div class="row">
          <div class="field" style="flex:0 1 200px">
            <label for="imp-lang">Melyik nyelvhez</label>
            <select class="sel" id="imp-lang" name="lang">
              <?php foreach (admin_langs() as $code => $label): ?>
                <option value="<?= h($code) ?>" <?= $code === $lang ? 'selected' : '' ?>><?= h($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field" style="flex:2 1 320px">
            <label for="docx"><?= h(t('Word-fájl (.docx)')) ?></label>
            <input class="inp" id="docx" name="docx" type="file" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
          </div>
          <div class="field" style="flex:0 1 auto; align-self:flex-end">
            <button class="btn btn--p" type="submit"><?= h(t('Beolvasás')) ?></button>
          </div>
        </div>
        <div class="hint">
          <?= t('import.tagolas') ?>
        </div>
      </form>
    </div>
  </div>

  <?php if ($import):
      $stats = json_decode((string)$import['stats'], true) ?: [];
      $nNew = $nMod = $nSame = 0;
      foreach ($items as $it) {
          if ($it['match_state'] === 'new') { $nNew++; }
          elseif ($it['match_state'] === 'same') { $nSame++; }
          else { $nMod++; }
      }
  ?>
  <div class="panel">
    <div class="panel__h">
      <h2><?= h($import['filename']) ?></h2>
      <span class="badge badge--info"><?= h($import['lang']) ?></span>
      <span class="badge"><?= help_bytes((int)$import['bytes']) ?></span>
      <span class="badge <?= $import['status'] === 'applied' ? 'badge--ok' : '' ?>"><?= h($import['status']) ?></span>
      <span class="sp"></span>
      <span class="muted"><?= h(substr((string)$import['uploaded_at'], 0, 16)) ?> · <?= h((string)$import['display_name']) ?></span>
    </div>

    <div class="panel__b">
      <div class="stats" style="margin-bottom:0">
 <div class="stat"><div class="stat__n"><?= count($items) ?></div><div class="stat__l">fejezet a dokumentumban</div></div>
 <div class="stat stat--warn"><div class="stat__n"><?= $nMod ?></div><div class="stat__l"><?= h(t('eltér a mostanitól')) ?></div></div>
 <div class="stat"><div class="stat__n"><?= $nSame ?></div><div class="stat__l"><?= h(t('változatlan')) ?></div></div>
 <div class="stat"><div class="stat__n"><?= $nNew ?></div><div class="stat__l"><?= h(t('új fejezet')) ?></div></div>
 <div class="stat"><div class="stat__n"><?= (int)($stats['images'] ?? 0) ?></div><div class="stat__l"><?= h(t('új kép kibontva')) ?></div></div>
      </div>
    </div>

    <form method="post" action="<?= h(admin_url()) ?>" id="imp-form">
      <?= csrf_input() ?>
      <input type="hidden" name="a" value="import.apply">
      <input type="hidden" name="import_id" value="<?= (int)$import['id'] ?>">

      <div class="panel__h" style="border-top:1px solid var(--line-soft)">
        <button class="btn btn--sm" type="button" id="imp-all"><?= h(t('Eltérők kijelölése')) ?></button>
        <button class="btn btn--sm" type="button" id="imp-none"><?= h(t('Kijelölés törlése')) ?></button>
        <span class="sp"></span>
        <label class="check"><input type="checkbox" name="publish_now"> <?= h(t('Átvétel után rögtön közzé is teszem')) ?></label>
        <button class="btn btn--p" type="submit"><?= h(t('Kijelöltek átvétele')) ?></button>
      </div>

      <div class="panel__b panel__b--flush">
        <div class="diff-legend" style="padding:10px 14px 0">
          <span><i style="background:var(--err-soft);color:var(--err)"><?= h(t('– törölt')) ?></i></span>
          <span><i style="background:var(--ok-soft);color:var(--ok)"><?= h(t('+ új')) ?></i></span>
          <span class="muted"><?= h(t('a jelenlegi közzétett szöveghez képest')) ?></span>
        </div>

        <?php foreach ($items as $it):
            $state = $it['match_state'];
            $badge = match ($state) {
                'new'  => '<span class="badge badge--info">' . h(t('új fejezet')) . '</span>',
                'same' => '<span class="badge">' . h(t('változatlan')) . '</span>',
                default => '<span class="badge badge--warn">' . number_format((float)$it['similarity'], 1, ',', ' ') . '% egyezés</span>',
            };
        ?>
          <div class="imp-item<?= $it['applied'] ? ' applied' : '' ?>" data-state="<?= h($state) ?>">
            <label class="imp-head">
              <input type="checkbox" name="items[]" value="<?= (int)$it['id'] ?>"
                     <?= $state === 'same' || $it['applied'] ? '' : 'checked' ?>>
              <span class="t"><em><?= h($it['chapter_no']) ?></em><?= h($it['title']) ?></span>
              <?php if ((int)$it['img_count']): ?><span class="badge"><?= (int)$it['img_count'] ?> <?= h(t('kép')) ?></span><?php endif; ?>
              <?= $badge ?>
              <?php if ($it['applied']): ?><span class="badge badge--ok"><?= h(t('átvéve')) ?></span><?php endif; ?>
              <button class="btn btn--sm btn--ghost" type="button" data-imp-toggle><?= h(t('Összehasonlítás')) ?></button>
            </label>
            <div class="imp-body">
              <?php
              if ($state === 'new') {
                  echo '<div class="msg msg--info" style="margin-bottom:10px">Ez a fejezet még nincs az adatbázisban — '
                     . 'átvételkor létrejön (rejtett vázlatként, amíg közzé nem teszed).</div>';
                  echo '<div class="diff">' . htmlspecialchars(mb_substr((string)$it['plain_text'], 0, 4000), ENT_QUOTES, 'UTF-8') . '</div>';
              } else {
                  $d = diff_html((string)$it['cur_plain'], (string)$it['plain_text']);
                  echo '<div class="hint" style="margin-bottom:8px">'
                     . '<b>' . $d['added'] . '</b> új szó, <b>' . $d['removed'] . '</b> elhagyott szó'
                     . ($it['cur_title'] !== $it['title']
                        ? ' · a cím is változik: „' . h((string)$it['cur_title']) . '” → „' . h((string)$it['title']) . '”'
                        : '')
                     . '</div>';
 echo '<div class="diff">' . ($d['changed'] ? $d['html'] : '<span class="muted">' . h(t('A szöveg szó szerint megegyezik a mostanival.')) . '</span>') . '</div>';
              }
              ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </form>

    <div class="panel__h" style="border-top:1px solid var(--line-soft)">
      <span class="sp"></span>
      <form method="post" action="<?= h(admin_url()) ?>" data-confirm="<?= h(t('Eldobod ezt az importot? A fejezetek érintetlenek maradnak.')) ?>">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="import.discard">
        <input type="hidden" name="import_id" value="<?= (int)$import['id'] ?>">
        <button class="btn btn--sm btn--danger" type="submit"><?= h(t('Import eldobása')) ?></button>
      </form>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($recent): ?>
  <div class="panel" style="margin-top:16px">
    <div class="panel__h"><h2><?= h(t('Korábbi importok')) ?></h2></div>
    <div class="panel__b panel__b--flush">
      <table class="tbl">
        <thead><tr><th><?= h(t('Fájl')) ?></th><th><?= h(t('Nyelv')) ?></th><th><?= h(t('Tartalom')) ?></th><th><?= h(t('Állapot')) ?></th><th><?= h(t('Mikor')) ?></th><th><?= h(t('Ki')) ?></th></tr></thead>
        <tbody>
        <?php foreach ($recent as $r): $s = json_decode((string)$r['stats'], true) ?: []; ?>
          <tr>
            <td data-label="<?= h(t('Fájl')) ?>"><a href="<?= h(admin_url(['p' => 'import', 'import' => $r['id']])) ?>"><?= h($r['filename']) ?></a></td>
            <td data-label="Nyelv"><span class="badge"><?= h($r['lang']) ?></span></td>
            <td class="muted" data-label="Tartalom"><?= (int)($s['chapters'] ?? 0) ?> fejezet · <?= (int)($s['images'] ?? 0) ?> <?= h(t('kép')) ?></td>
            <td data-label="<?= h(t('Állapot')) ?>"><span class="badge <?= $r['status'] === 'applied' ? 'badge--ok' : '' ?>"><?= h($r['status']) ?></span></td>
            <td class="nowrap muted" data-label="Mikor"><?= h(substr((string)$r['uploaded_at'], 0, 16)) ?></td>
            <td class="muted" data-label="Ki"><?= h((string)$r['display_name']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>
</div>
    <?php
    admin_foot();
}

// ============================================================ FORDÍTÁS
function page_translate(PDO $db, array $cfg, int $srcId, string $to, array $counts,
                        string $state = 'all', string $left = '', string $right = ''): void
{
    // Ket nyelv latszik egymas mellett, es a SZERKESZTO valasztja meg, melyik
    // ketto. Alapertelmezes: a forras (magyar) es az elso celnyelv.
    $langCodes = array_keys(admin_langs());
    if (!in_array($left, $langCodes, true))  { $left  = admin_source_lang(); }
    if (!in_array($right, $langCodes, true)) { $right = (string)array_key_first(admin_target_langs()); }
    if ($left === $right) {
        $right = $left === admin_source_lang()
               ? (string)array_key_first(admin_target_langs())
               : admin_source_lang();
    }
    $STATES = ['all' => t('Mind'), 'missing' => t('Hiányzik'), 'stale' => t('Elavult'),
               'draft' => t('Vázlat'), 'ok' => t('Naprakész')];
    if (!isset($STATES[$state])) { $state = 'all'; }

    $tr = Translator::fromConfig($cfg, $db);
    if (!array_key_exists($to, admin_langs()) || $to === 'hu') { $to = 'en'; }

    $src = null; $target = null;
    if ($srcId > 0) {
        $st = $db->prepare("SELECT a.*, m.title AS module_title FROM help_article a
                              LEFT JOIN help_module m ON m.id = a.module_id
                             WHERE a.id = ? AND a.lang = 'hu'");
        $st->execute([$srcId]);
        $src = $st->fetch() ?: null;
        if ($src) {
            // A nyelvi valtozatokat a FEJEZETSZAM koti ossze: a slug mar
            // nyelvenkent elter (az angol oldal angol cimet kap), ezert a
            // slug szerinti parositas minden forditast "hianyzonak" mutatott.
            $target = null;
            if ((string)$src['chapter_no'] !== '') {
                $t = $db->prepare('SELECT * FROM help_article WHERE chapter_no = ? AND lang = ? LIMIT 1');
                $t->execute([$src['chapter_no'], $to]);
                $target = $t->fetch() ?: null;
            }
            if (!$target) {
                $t = $db->prepare('SELECT * FROM help_article WHERE slug = ? AND lang = ? LIMIT 1');
                $t->execute([$src['slug'], $to]);
                $target = $t->fetch() ?: null;
            }
        }
    }

    // A magyar lista, MINDEN celnyelv allapotaval. Korabban egy "Celnyelv"
    // valaszto dontotte el, melyik nyelvre vonatkoznak a cimkek - de ez
    // sehol nem latszott, ezert ugy tunt, mintha semmit nem csinalna.
    // Most nyelvenkent kulon cimke all a sorban.
    $targetCodes = array_keys(admin_target_langs());

    $rows = $db->query("
        SELECT s.id, s.chapter_no, s.title, s.slug, s.content_hash,
               m.title AS module_title, m.chapter_no AS module_no
          FROM help_article s
          LEFT JOIN help_module m ON m.id = s.module_id
         WHERE s.lang = 'hu'
      ORDER BY m.sort_order, s.sort_order, s.id")->fetchAll();

    $tq = $db->prepare("SELECT lang, chapter_no, slug, translated_from_hash,
                               draft_html IS NOT NULL AS t_draft, is_published
                          FROM help_article WHERE lang <> 'hu'");
    $tq->execute();
    $byNo = [];
    $bySlug = [];
    foreach ($tq->fetchAll() as $t) {
        if ((string)$t['chapter_no'] !== '') { $byNo[$t['lang'] . '|' . $t['chapter_no']] = $t; }
        $bySlug[$t['lang'] . '|' . $t['slug']] = $t;
    }

    /** Egy fejezet allapota egy adott celnyelven. */
    $stateIn = static function (array $r, string $code) use ($byNo, $bySlug): array {
        $t = $byNo[$code . '|' . $r['chapter_no']] ?? $bySlug[$code . '|' . $r['slug']] ?? null;
        if (!$t)                                                { return ['missing', 'badge--err',  t('hiányzik')]; }
        if ($t['translated_from_hash'] !== $r['content_hash'])   { return ['stale',   'badge--warn', 'elavult']; }
        if ($t['t_draft'])                                      { return ['draft',   'badge--info', t('vázlat')]; }
        return ['ok', 'badge--ok', t('naprakész')];
    };

    /** A fejezet OSSZESITETT allapota: a legrosszabb a celnyelvek kozul. */
    $stateOf = static function (array $r) use ($stateIn, $targetCodes): array {
        $rank = ['missing' => 0, 'stale' => 1, 'draft' => 2, 'ok' => 3];
        $worst = null;
        foreach ($targetCodes as $c) {
            $st = $stateIn($r, $c);
            if ($worst === null || $rank[$st[0]] < $rank[$worst[0]]) { $worst = $st; }
        }
        return $worst ?? ['ok', 'badge--ok', t('naprakész')];
    };
    $list = $rows;

    // allapotonkenti darabszam a szurogombokra
    $stateCount = ['missing' => 0, 'stale' => 0, 'draft' => 0, 'ok' => 0];
    foreach ($list as $r) {
        $stateCount[$stateOf($r)[0]]++;
    }
    if ($state !== 'all') {
        $list = array_values(array_filter($list, static fn(array $r): bool => $stateOf($r)[0] === $state));
    }

    admin_head(t('Fordítás'), 'translate', $counts);
    ?>
<div class="page page--tr">
  <h1 class="pt"><?= h(t('Fordítás')) ?></h1>
  <p class="lead">
    <?= t('forditas.magyarazat') ?>
  </p>
  <?= flash_render() ?>

 <div class="panel panel__b" style="margin-bottom:14px"><div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center">
    <div>
      <span class="lbl" style="display:inline"><?= h(t('Állapot:')) ?></span>
      <?php foreach ($STATES as $code => $label): ?>
        <a class="btn btn--sm <?= $state === $code ? 'btn--p' : '' ?>"
           href="<?= h(admin_url(['p' => 'translate', 'to' => $to, 'st' => $code] + ($srcId ? ['src' => $srcId] : []))) ?>">
          <?= h($label) ?><?php if ($code !== 'all'): ?>
            <span class="badge" style="margin-left:4px"><?= (int)($stateCount[$code] ?? 0) ?></span>
          <?php endif; ?></a>
      <?php endforeach; ?>
    </div>
    <span style="flex:1"></span>
    <div class="muted">
      <?= h(t('Gépi fordító:')) ?> <b><?= h($tr->label()) ?></b>
      <?php if (!$tr->isConfigured()): ?>
        — <a href="<?= h(admin_url(['p' => 'settings'])) ?>"><?= h(t('beállítás')) ?></a>. Enélkül a kézi fordítás működik.
      <?php endif; ?>
    </div>
  </div></div>

  <div class="page--split" style="padding:0">
    <!-- fejezetlista -->
    <div class="panel picker">
 <div class="picker__f inp"><input id="pick-filter" placeholder="<?= h(t('Szűrés…')) ?>" autocomplete="off"></div>
      <div class="picker__l" id="pick-list">
        <?php
        $curModule = null;
        foreach ($list as $r):
            if ($curModule !== $r['module_title']) {
                $curModule = $r['module_title'];
                echo '<div class="picker__m">' . h((string)$r['module_no']) . ' ' . h((string)$curModule) . '</div>';
            }
            [$state, $cls, $label] = $stateOf($r);
        ?>
          <a class="picker__a<?= (int)$r['id'] === $srcId ? ' on' : '' ?>"
             href="<?= h(admin_url(['p' => 'translate', 'to' => $to, 'st' => $state, 'src' => $r['id']])) ?>">
            <em><?= h($r['chapter_no']) ?></em><span><?= h($r['title']) ?></span>
            <span class="picker__langs">
              <?php foreach ($targetCodes as $code):
                  [$st2, $cls2, $lbl2] = $stateIn($r, $code); ?>
                <span class="badge <?= $cls2 ?>" title="<?= h(admin_langs()[$code] . ': ' . $lbl2) ?>"><?= h(strtoupper($code)) ?></span>
              <?php endforeach; ?>
            </span>
          </a>
        <?php endforeach; ?>
        <?php if (!$list): ?>
          <div class="empty" style="padding:22px 16px"><?= h(t('Ebben az állapotban nincs fejezet.')) ?></div>
        <?php endif; ?>
      </div>
    </div>


    <!-- szerkesztő -->
    <div>
      <?php if (!$src): ?>
 <div class="panel"><div class="empty"><?= h(t('Válassz egy fejezetet a bal oldali listából.')) ?></div></div>
      <?php else: ?>
        <?php
        // MINDEN celnyelv egy oldalon. Uj nyelv felvetele az admin_langs()-ban
        // eleg - itt magatol megjelenik egy uj oszlop.
        $targets = [];
        foreach (array_keys(admin_target_langs()) as $code) {
            $row = null;
            if ((string)$src['chapter_no'] !== '') {
                $q = $db->prepare('SELECT * FROM help_article WHERE chapter_no = ? AND lang = ? LIMIT 1');
                $q->execute([$src['chapter_no'], $code]);
                $row = $q->fetch() ?: null;
            }
            if (!$row) {
                $q = $db->prepare('SELECT * FROM help_article WHERE slug = ? AND lang = ? LIMIT 1');
                $q->execute([$src['slug'], $code]);
                $row = $q->fetch() ?: null;
            }
            $targets[$code] = $row;
        }
        ?>

        <?php
        /** Egy nyelv adatlapja: a forras csak olvashato, a celnyelv szerkesztheto. */
        $pane = function (string $code) use ($db, $src, $targets, $tr) {
            $isSource = $code === admin_source_lang();
            $row = $isSource ? $src : ($targets[$code] ?? null);

            $draft  = $row && $row['draft_html'] !== null
                      && trim(help_plain((string)$row['draft_html'])) !== '';
            $body   = $row ? (string)($draft ? $row['draft_html'] : $row['body_html']) : '';
            $title  = $row ? (string)($draft && (string)($row['draft_title'] ?? '') !== ''
                                      ? $row['draft_title'] : $row['title']) : '';
            $stale  = !$isSource && $row && $row['translated_from_hash'] !== $src['content_hash'];
            return compact('isSource', 'row', 'draft', 'body', 'title', 'stale');
        };
        ?>

        <div class="tr-grid tr-grid--multi" style="--tr-cols: 2">
          <?php foreach ([$left, $right] as $slot => $code):
              $d = $pane($code);
              $other = $slot === 0 ? $right : $left;
          ?>
            <?php if ($d['isSource']): ?>
              <div class="panel tr-col">
                <div class="panel__h">
                  <select class="ed-sel tr-lang" data-slot="<?= (int)$slot ?>">
                    <?php foreach (admin_langs() as $c => $lbl): ?>
                      <option value="<?= h($c) ?>" <?= $c === $code ? 'selected' : '' ?>
                              <?= $c === $other ? 'disabled' : '' ?>><?= h($lbl) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <span class="badge"><?= h(t('forrás')) ?></span>
                  <span class="sp"></span>
                  <?php if ($d['draft']): ?><span class="badge badge--warn"><?= h(t('vázlat')) ?></span><?php endif; ?>
                  <span class="badge"><?= h($src['chapter_no']) ?></span>
                </div>
                <div class="panel__b">
                  <div class="field"><label><?= h(t('Cím')) ?></label>
                    <input class="inp" value="<?= h($d['title']) ?>" readonly></div>
                  <div class="tr-src body"><?= fix_img_url($d['body']) ?></div>
                </div>
              </div>

            <?php else: ?>
              <form class="panel tr-col" method="post" action="<?= h(admin_url()) ?>"
                    data-tr-lang="<?= h($code) ?>">
                <?= csrf_input() ?>
                <input type="hidden" name="a" value="translate.save">
                <input type="hidden" name="src_id" value="<?= (int)$src['id'] ?>">
                <input type="hidden" name="to" value="<?= h($code) ?>">
                <input type="hidden" name="how" class="tr-how" value="manual">

                <div class="panel__h">
                  <select class="ed-sel tr-lang" data-slot="<?= (int)$slot ?>">
                    <?php foreach (admin_langs() as $c => $lbl): ?>
                      <option value="<?= h($c) ?>" <?= $c === $code ? 'selected' : '' ?>
                              <?= $c === $other ? 'disabled' : '' ?>><?= h($lbl) ?></option>
                    <?php endforeach; ?>
                  </select>
                  <span class="sp"></span>
                  <?php if (!$d['row']): ?><span class="badge badge--err"><?= h(t('hiányzik')) ?></span>
                  <?php elseif ($d['stale']): ?><span class="badge badge--warn">elavult</span>
                  <?php elseif ($d['draft']): ?><span class="badge badge--info"><?= h(t('vázlat')) ?></span>
                  <?php else: ?><span class="badge badge--ok"><?= h(t('naprakész')) ?></span><?php endif; ?>
                  <button class="btn btn--sm tr-machine" type="button"
                          <?= $tr->isConfigured() ? '' : 'disabled title="' . h(t('Nincs beállítva gépi fordító')) . '"' ?>><?= h(t('Gépi nyersfordítás')) ?></button>
                </div>

                <div class="panel__b">
                  <div class="field"><label><?= h(t('Cím')) ?></label>
                    <input class="inp tr-title" name="title" value="<?= h($d['title']) ?>"></div>
                  <?php editor_block((string)$src['chapter_no'], $d['body']); ?>
                  <div class="btnbar" style="margin-top:10px">
                    <button class="btn btn--p btn--sm" type="submit"><?= h(t('Mentés vázlatként')) ?></button>
                    <label class="check"><input type="checkbox" name="publish_now"> <?= h(t('közzététel is')) ?></label>
                    <span style="flex:1"></span>
                    <?php if ($d['row']): ?>
                      <a class="btn btn--sm btn--ghost"
                         href="<?= h(admin_url(['p' => 'articles', 'lang' => $code, 'id' => $d['row']['id']])) ?>"><?= h(t('Megnyitás')) ?></a>
                    <?php endif; ?>
                  </div>
                </div>
              </form>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>

        <div class="btnbar" style="margin-top:12px">
          <button class="btn" type="submit" form="tr-auto-form"
                  <?= $tr->isConfigured() ? '' : 'disabled title="' . h(t('Nincs beállítva gépi fordító')) . '"' ?>>
            <?= t('Gépi nyersfordítás <b>mindegyik nyelvre</b>') ?>
          </button>
          <span class="muted"><?= h(t('A gépi fordítás mindig vázlatot készít — közzétenni külön kell.')) ?></span>
        </div>

<form method="post" action="<?= h(admin_url()) ?>" id="tr-auto-form">
  <?= csrf_input() ?>
  <input type="hidden" name="a" value="translate.auto">
  <input type="hidden" name="src_id" value="<?= (int)$src['id'] ?>">
</form>
      <?php endif; ?>
    </div>
  </div>
</div>

  <?php // Az oldalcimek is NYELVENKENTI SZOVEGEK, ezert ide tartoznak, nem a
        // beallitasok koze: itt dolgozol a nyelvi valtozatokkal. ?>
  <div class="panel" style="margin-bottom:16px">
      <div class="panel__h"><h2><?= h(t('Oldalcímek')) ?></h2></div>
      <div class="panel__b">
        <form method="post" action="<?= h(admin_url()) ?>">
          <?= csrf_input() ?>
          <input type="hidden" name="a" value="setting.save">
          <div class="row">
            <?php foreach (admin_langs() as $code => $label): ?>
              <div class="field"><label><?= h($label) ?></label>
                <input class="inp" name="site_title_<?= h($code) ?>" value="<?= h(admin_setting($db, 'site_title_' . $code)) ?>"></div>
            <?php endforeach; ?>
          </div>
          <div class="hint" style="margin-top:4px">
            <b><?= h(t('Újdonságjelzés:')) ?></b> a közzétett fejezet <b><?= h(t('ÚJ')) ?></b> vagy <b><?= h(t('FRISSÍTVE')) ?></b> címkét kap a bal
            sávban, és felkerül a <b><?= h(t('Újdonságok')) ?></b> lapra. A jelzés a <b><?= h(t('kiadás lezárásáig')) ?></b> marad kint
            (Beállítások → Kiadások) — nem jár le magától. Az „apró javítás" jelöléssel közzétett
            módosítás nem kelti újra a jelzést.
          </div>
          <button class="btn btn--p" type="submit"><?= h(t('Mentés')) ?></button>
        </form>
      </div>
    </div>
    <?php
    admin_foot();
}

// ============================================================ KÉPERNYŐK
function page_screens(PDO $db, array $counts): void
{
    $rows = $db->query("SELECT s.*, a.chapter_no, a.title, a.lang, a.slug
                          FROM help_screen_map s JOIN help_article a ON a.id = s.article_id
                      ORDER BY s.route")->fetchAll();
    $arts = $db->query("SELECT id, chapter_no, title FROM help_article WHERE lang = 'hu' ORDER BY sort_order, id")->fetchAll();

    admin_head(t('Képernyők'), 'screens', $counts);
    ?>
<div class="page">
  <h1 class="pt"><?= h(t('Képernyő → fejezet hozzárendelés')) ?></h1>
  <p class="lead"><?= t('Ez mondja meg, hogy az Infinity egy adott képernyőjén a <b>?</b> gomb melyik fejezetet nyissa meg. Az útvonal az Infinity route-ja, például <span class="mono">penzugy/egyenleg/index') ?></span>.
  </p>
  <?= flash_render() ?>

  <div class="panel" style="margin-bottom:16px">
    <div class="panel__h"><h2><?= h(t('Új hozzárendelés')) ?></h2></div>
    <div class="panel__b">
      <form method="post" action="<?= h(admin_url()) ?>">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="screen.save">
        <div class="row">
          <div class="field" style="flex:2 1 260px"><label><?= h(t('Útvonal (route)')) ?></label>
            <input class="inp mono" name="route" placeholder="penzugy/egyenleg/index" required></div>
          <div class="field" style="flex:3 1 320px"><label><?= h(t('Fejezet')) ?></label>
            <select class="sel" name="article_id" required>
              <?php foreach ($arts as $a): ?>
                <option value="<?= (int)$a['id'] ?>"><?= h($a['chapter_no'] . ' ' . $a['title']) ?></option>
              <?php endforeach; ?>
            </select></div>
          <div class="field"><label><?= h(t('Horgony (opcionális)')) ?></label>
            <input class="inp mono" name="anchor" placeholder="5-4-2-egyenlegkozlo"></div>
          <div class="field" style="flex:0 1 auto;align-self:flex-end">
            <button class="btn btn--p" type="submit"><?= h(t('Hozzáadás')) ?></button></div>
        </div>
      </form>
    </div>
  </div>

  <div class="panel">
 <div class="panel__h"><h2><?= h(t('Meglévő hozzárendelések')) ?></h2><span class="sp"></span><span class="badge"><?= count($rows) ?></span></div>
    <div class="panel__b panel__b--flush">
      <?php if (!$rows): ?>
        <div class="empty"><?= h(t('Még nincs egyetlen hozzárendelés sem.')) ?></div>
      <?php else: ?>
        <table class="tbl">
          <thead><tr><th><?= h(t('Útvonal')) ?></th><th><?= h(t('Fejezet')) ?></th><th><?= h(t('Horgony')) ?></th><th><?= h(t('Ellenőrzött')) ?></th><th></th></tr></thead>
          <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td class="mono" data-label="<?= h(t('Útvonal')) ?>"><?= h($r['route']) ?></td>
              <td><a href="<?= h(admin_url(['p' => 'articles', 'lang' => $r['lang'], 'id' => $r['article_id']])) ?>">
                <?= h($r['chapter_no'] . ' ' . $r['title']) ?></a></td>
              <td class="mono muted" data-label="Horgony"><?= h((string)$r['anchor']) ?></td>
 <td data-label="<?= h(t('Ellenőrzött')) ?>"><?= $r['is_verified'] ? '<span class="badge badge--ok">igen</span>' : '<span class="badge">nem</span>' ?></td>
              <td class="nowrap">
                <form method="post" action="<?= h(admin_url()) ?>" data-confirm="<?= h(t('Törlöd ezt a hozzárendelést?')) ?>">
                  <?= csrf_input() ?>
                  <input type="hidden" name="a" value="screen.delete">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="btn btn--sm btn--danger" type="submit"><?= h(t('Törlés')) ?></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
</div>
    <?php
    admin_foot();
}

// ============================================================ KÉPEK ÉS VIDEÓK
function page_media(PDO $db, array $cfg, int $page, array $counts): void
{
    $dir = media_dir($cfg);
    $files = is_dir($dir)
        ? (glob($dir . '/*.{png,jpg,jpeg,gif,webp,svg,mp4,webm,mov}', GLOB_BRACE) ?: [])
        : [];
    usort($files, static fn($a, $b) => filemtime($b) <=> filemtime($a));

    $filter = (string)($_GET['kind'] ?? 'all');
    if ($filter === 'video') {
        $files = array_values(array_filter($files, static fn($f) => (bool)preg_match('/\.(mp4|webm|mov)$/i', $f)));
    } elseif ($filter === 'image') {
        $files = array_values(array_filter($files, static fn($f) => !preg_match('/\.(mp4|webm|mov)$/i', $f)));
    }

    $total   = count($files);
    $perPage = 48;
    $page    = max(1, $page);
    $slice   = array_slice($files, ($page - 1) * $perPage, $perPage);
    $pages   = max(1, (int)ceil($total / $perPage));
    $writable = is_dir($dir) && is_writable($dir);

    admin_head(t('Képek, videók'), 'media', $counts);
    ?>
<div class="page">
  <h1 class="pt"><?= h(t('Képek és videók')) ?></h1>
  <p class="lead">
    Ez a fájltár. <b><?= h(t('Szerkesztés közben nem kell ide jönni')) ?></b> — a fejezetszerkesztőben a
    <b><?= h(t('Kép')) ?></b> és a <b><?= h(t('Videó')) ?></b> gombbal (vagy a fájlt egyszerűen a szövegre húzva) közvetlenül
    feltölthetsz. Ez az oldal az áttekintésre és a tömeges feltöltésre való.
    A fájlnév a tartalom hash-e, ezért ugyanaz a fájl csak egyszer kerül a szerverre.
  </p>
  <?= flash_render() ?>

  <?php if (!$writable): ?>
 <div class="msg msg--warn"><span class="msg__h"><?= h(t('A fájlok mappája nem írható')) ?></span> (<span class="mono"><?= h($dir) ?></span>).
      Feltöltés és Word-import képkibontás nem fog működni.</div>
  <?php endif; ?>

  <div class="panel" style="margin-bottom:16px">
 <div class="panel__h"><h2><?= h(t('Feltöltés')) ?></h2><span class="sp"></span>
      <span class="badge"><?= $total ?> <?= h(t('fájl')) ?></span></div>
    <div class="panel__b">
      <form method="post" action="<?= h(admin_url()) ?>" enctype="multipart/form-data">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="media.upload">
        <div class="row">
          <div class="field" style="flex:3 1 320px">
            <label for="files"><?= h(t('Fájlok (több is egyszerre)')) ?></label>
            <input class="inp" id="files" name="files[]" type="file"
                   accept="image/*,video/mp4,video/webm,video/quicktime" multiple required <?= $writable ? '' : 'disabled' ?>>
            <div class="hint">
              Kép: PNG, JPG, GIF, WebP, SVG — legfeljebb <?= help_bytes(MEDIA_MAX_IMAGE) ?>.
              Videó: MP4, WebM, MOV — legfeljebb <?= help_bytes(MEDIA_MAX_VIDEO) ?>.
              A böngészőkben a <b>H.264-es MP4</b> és a <b>WebM</b> játszható le mindenhol.
            </div>
          </div>
          <div class="field" style="flex:0 1 auto;align-self:flex-start;margin-top:22px">
            <button class="btn btn--p" type="submit" <?= $writable ? '' : 'disabled' ?>><?= h(t('Feltöltés')) ?></button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <div class="panel">
    <div class="panel__h">
      <h2><?= h(t('Fájlok')) ?></h2>
      <span class="sp"></span>
      <?php foreach (['all' => 'Mind', 'image' => 'Képek', 'video' => 'Videók'] as $k => $lbl): ?>
        <a class="btn btn--sm <?= $filter === $k ? 'btn--p' : '' ?>"
           href="<?= h(admin_url(['p' => 'media', 'kind' => $k])) ?>"><?= h($lbl) ?></a>
      <?php endforeach; ?>
      <span style="width:12px"></span>
      <?php if ($page > 1): ?>
        <a class="btn btn--sm" href="<?= h(admin_url(['p' => 'media', 'kind' => $filter, 'page' => $page - 1])) ?>"><?= h(t('← Előző')) ?></a>
      <?php endif; ?>
      <span class="muted"><?= $page ?>. / <?= $pages ?></span>
      <?php if ($page < $pages): ?>
        <a class="btn btn--sm" href="<?= h(admin_url(['p' => 'media', 'kind' => $filter, 'page' => $page + 1])) ?>"><?= h(t('Következő →')) ?></a>
      <?php endif; ?>
    </div>
    <div class="panel__b">
      <?php if (!$slice): ?>
        <div class="empty"><?= h(t('Nincs ilyen fájl.')) ?></div>
      <?php else: ?>
        <div class="grid-media">
          <?php foreach ($slice as $f):
              $n = basename($f);
              $isVideo = (bool)preg_match('/\.(mp4|webm|mov)$/i', $n);
          ?>
            <div class="mcard">
              <?php if ($isVideo): ?>
                <video src="/media/<?= h(rawurlencode($n)) ?>" preload="metadata" muted playsinline></video>
                <span class="mcard__tag"><?= h(t('videó')) ?></span>
              <?php else: ?>
                <img src="/media/<?= h(rawurlencode($n)) ?>" alt="<?= h($n) ?>" loading="lazy">
              <?php endif; ?>
              <div class="c">
                <span class="mono"><?= h($n) ?></span><br>
                <?= help_bytes((int)filesize($f)) ?>
                <form method="post" action="<?= h(admin_url()) ?>" style="display:inline;float:right"
                      data-confirm="<?= h(t('Törlöd ezt a fájlt? Csak akkor sikerül, ha egyetlen fejezet sem hivatkozik rá.')) ?>">
                  <?= csrf_input() ?>
                  <input type="hidden" name="a" value="media.delete">
                  <input type="hidden" name="filename" value="<?= h($n) ?>">
                  <button class="btn btn--sm btn--ghost" type="submit" title="<?= h(t('Törlés')) ?>">✕</button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
    <?php
    admin_foot();
}

// ============================================================ EXPORT
function page_export(PDO $db, array $cfg, string $lang, array $counts): void
{
    $rows = $db->query("
        SELECT lang,
               COUNT(CASE WHEN is_published = 1 THEN 1 END) AS published,
               COUNT(CASE WHEN is_published = 0 THEN 1 END) AS hidden,
               SUM(img_count)                              AS images
          FROM help_article GROUP BY lang ORDER BY lang")->fetchAll();
    $stat = [];
    foreach ($rows as $r) { $stat[$r['lang']] = $r; }
    $version = (string)$db->query("SELECT COALESCE(MAX(doc_version), '') FROM help_article")->fetchColumn();
    $hasPdf  = pdf_engine() !== null;

    admin_head('Export', 'export', $counts);
    ?>
<div class="page" style="max-width:1000px">
  <h1 class="pt"><?= h(t('A használati útmutató exportálása')) ?></h1>
  <p class="lead">
    A teljes útmutató letölthető <b>Word</b>- és <b>PDF</b>-fájlként. Mindkettő rendes
    kézikönyv: címlap (fejléc és lábléc nélkül), <b><?= h(t('tartalomjegyzék oldalszámokkal')) ?></b>, minden
    lap tetején a logó, alul balra az <b><?= h(t('aktuális modul neve')) ?></b>, jobbra az <b><?= h(t('oldalszám')) ?></b>.
    Mindig a <b><?= h(t('jelenlegi, közzétett')) ?></b> adatbázis-tartalomból készül, nem egy korábbi pillanatképből.
  </p>
  <?= flash_render() ?>

  <div class="panel">
 <div class="panel__h"><h2><?= h(t('Letöltés')) ?></h2><span class="sp"></span>
      <?php if ($version !== ''): ?><span class="badge badge--info"><?= h($version) ?></span><?php endif; ?></div>
    <div class="panel__b panel__b--flush">
      <table class="tbl">
 <thead><tr><th><?= h(t('Nyelv')) ?></th><th class="num"><?= h(t('Közzétett fejezet')) ?></th><th class="num"><?= h(t('Kikapcsolt')) ?></th>
          <th class="num"><?= h(t('Kép')) ?></th><th><?= h(t('Letöltés')) ?></th></tr></thead>
        <tbody>
        <?php foreach (admin_langs() as $code => $label):
            $s = $stat[$code] ?? ['published' => 0, 'hidden' => 0, 'images' => 0]; ?>
          <tr>
            <td><b><?= h($label) ?></b> <span class="badge"><?= h($code) ?></span></td>
            <td class="num" data-label="<?= h(t('Közzétett')) ?>"><?= (int)$s['published'] ?></td>
 <td class="num" data-label="Kikapcsolt"><?= (int)$s['hidden'] ? '<span class="badge badge--warn">' . (int)$s['hidden'] . '</span>' : '0' ?></td>
            <td class="num" data-label="<?= h(t('Kép')) ?>"><?= (int)$s['images'] ?></td>
            <td class="nowrap">
              <form method="post" action="<?= h(admin_url()) ?>" style="display:inline">
                <?= csrf_input() ?>
                <input type="hidden" name="a" value="export.docx">
                <input type="hidden" name="lang" value="<?= h($code) ?>">
                <button class="btn btn--sm btn--p" type="submit"><?= h(t('Word (.docx)')) ?></button>
              </form>
              <?php if ($hasPdf): ?>
                <form method="post" action="<?= h(admin_url()) ?>" style="display:inline">
                  <?= csrf_input() ?>
                  <input type="hidden" name="a" value="export.pdf">
                  <input type="hidden" name="lang" value="<?= h($code) ?>">
                  <button class="btn btn--sm btn--p" type="submit"
                          title="<?= h(t('Oldalszámmal, futó lábléccel, kattintható tartalomjegyzékkel')) ?>"><?= h(t('PDF')) ?></button>
                </form>
              <?php endif; ?>
              <a class="btn btn--sm btn--ghost" target="_blank" rel="noopener"
                 href="<?= h(admin_url(['a' => 'export.html', 'lang' => $code])) ?>"
                 title="<?= h(t('Megnyitás böngészőben (onnan is nyomtatható)')) ?>"><?= h(t('Előnézet')) ?></a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="panel__b">
      <?php if (!$hasPdf): ?>
        <div class="msg msg--warn">
          <b>Nincs PDF-motor a szerveren</b>, ezért a közvetlen PDF-letöltés nem érhető el.
          Telepítés: <span class="mono">apt-get install -y weasyprint</span> (a Docker-változat
          már tartalmazza). Addig az <b><?= h(t('Előnézet')) ?></b> gombbal megnyitott oldalról a böngésző
          <i>Nyomtatás → Mentés PDF-ként</i> funkciójával is készíthető PDF — abban viszont
          nincs oldalszám és futó lábléc, mert azt a böngésző nem tudja.
        </div>
      <?php endif; ?>
      <div class="msg msg--info" style="margin:0">
        <b><?= h(t('A Word-fájl tartalomjegyzéke automatikusan frissül.')) ?></b>
        A Wordben megnyitva a program felajánlja a mezők frissítését — vagy jelöld ki a
        tartalomjegyzéket és nyomj <span class="mono">F9</span>-et, hogy az oldalszámok bekerüljenek.
        A logó a címlapra és minden lap jobb felső sarkába kerül, ahogy az eredeti útmutatóban.
        A videók nem kerülnek bele a dokumentumba (a Word nem játssza le őket), a helyükön hivatkozás marad.
      </div>
    </div>
  </div>

  <div class="panel" style="margin-top:16px">
    <div class="panel__h"><h2><?= h(t('Kikapcsolt fejezetek')) ?></h2></div>
    <div class="panel__b">
      <form method="post" action="<?= h(admin_url()) ?>">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="export.docx">
        <div class="row">
          <div class="field" style="flex:0 1 200px"><label><?= h(t('Nyelv')) ?></label>
            <select class="sel" name="lang">
              <?php foreach (admin_langs() as $code => $label): ?>
                <option value="<?= h($code) ?>" <?= $code === $lang ? 'selected' : '' ?>><?= h($label) ?></option>
              <?php endforeach; ?>
            </select></div>
          <div class="field" style="align-self:center">
            <label class="check"><input type="checkbox" name="include_hidden" checked><?= h(t('A még nem közzétett (kikapcsolt) fejezetek is kerüljenek bele')) ?></label>
            <div class="hint"><?= h(t('Belső átnézésre hasznos: így a készülő fejezetek is benne lesznek a dokumentumban.')) ?></div>
          </div>
          <div class="field" style="flex:0 1 auto;align-self:center">
            <button class="btn" type="submit"><?= h(t('Letöltés mindennel')) ?></button></div>
        </div>
      </form>
    </div>
  </div>
</div>
    <?php
    admin_foot();
}

// ============================================================ FELHASZNÁLÓK
function page_users(PDO $db, array $counts): void
{
    $users = $db->query('SELECT * FROM help_user ORDER BY username')->fetchAll();
    $me = auth_user();

    admin_head(t('Felhasználók'), 'users', $counts);
    ?>
<div class="page">
  <h1 class="pt"><?= h(t('Felhasználók')) ?></h1>
  <p class="lead"><?= t('Szerepkörök: <b>admin</b> — mindent; <b>editor</b> — fejezetek, modulok, import, fordítás, képernyők, képek; <b>translator</b> — csak a Fordítás fül. A jelszó cseréje nem kötelező; a Beállítások fülön bármikor elvégezhető.') ?></p>
  <?= flash_render() ?>

  <div class="panel" style="margin-bottom:16px">
    <div class="panel__h"><h2><?= h(t('Új felhasználó')) ?></h2></div>
    <div class="panel__b">
      <form method="post" action="<?= h(admin_url()) ?>" autocomplete="off">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="user.save">
        <div class="row">
 <div class="field inp"><label><?= h(t('Felhasználónév')) ?></label><input name="username" required></div>
 <div class="field inp"><label><?= h(t('Név')) ?></label><input name="display_name"></div>
 <div class="field inp"><label><?= h(t('E-mail')) ?></label><input name="email" type="email"></div>
          <div class="field" style="flex:0 1 160px"><label><?= h(t('Szerepkör')) ?></label>
            <select class="sel" name="role">
              <option value="editor">editor</option>
              <option value="translator">translator</option>
              <option value="admin">admin</option>
            </select></div>
 <div class="field inp"><label><?= h(t('Kezdeti jelszó')) ?></label><input name="password" type="password" required minlength="8"></div>
 <div class="field btn btn--p" style="flex:0 1 auto;align-self:flex-end"><button type="submit"><?= h(t('Létrehozás')) ?></button></div>
        </div>
        <div class="hint"><?= h(t('Legalább 8 karakter, betű és szám is legyen benne.')) ?></div>
      </form>
    </div>
  </div>

  <div class="panel">
 <div class="panel__h"><h2><?= h(t('Meglévő felhasználók')) ?></h2><span class="sp"></span><span class="badge"><?= count($users) ?></span></div>
    <div class="panel__b panel__b--flush">
      <?php foreach ($users as $us): ?>
        <form method="post" action="<?= h(admin_url()) ?>" id="uf<?= (int)$us['id'] ?>">
          <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
          <input type="hidden" name="a" value="user.save">
          <input type="hidden" name="id" value="<?= (int)$us['id'] ?>">
        </form>
      <?php endforeach; ?>
      <table class="tbl">
        <thead><tr><th><?= h(t('Felhasználónév')) ?></th><th><?= h(t('Név')) ?></th><th><?= h(t('E-mail')) ?></th><th><?= h(t('Szerepkör')) ?></th><th><?= h(t('Aktív')) ?></th><th><?= h(t('Utolsó belépés')) ?></th><th></th></tr></thead>
        <tbody>
        <?php foreach ($users as $us): ?>
          <tr>
            <td data-label="<?= h(t('Felhasználónév')) ?>"><b><?= h($us['username']) ?></b>
              <?php if ($us['must_change_pw']): ?><br><span class="badge badge--warn"><?= h(t('jelszócsere vár')) ?></span><?php endif; ?>
              <?php if ($us['locked_until'] !== null && strtotime((string)$us['locked_until']) > time()): ?>
                <br><span class="badge badge--err"><?= h(t('zárolva')) ?></span><?php endif; ?>
            </td>
            <td data-label="<?= h(t('Név')) ?>"><input class="inp" form="uf<?= (int)$us['id'] ?>" name="display_name" value="<?= h($us['display_name']) ?>"></td>
            <td data-label="E-mail"><input class="inp" form="uf<?= (int)$us['id'] ?>" name="email" value="<?= h((string)$us['email']) ?>"></td>
            <td data-label="<?= h(t('Szerepkör')) ?>"><select class="sel" form="uf<?= (int)$us['id'] ?>" name="role">
                <?php foreach (HELP_ROLES as $r): ?>
                  <option value="<?= h($r) ?>" <?= $r === $us['role'] ? 'selected' : '' ?>><?= h($r) ?></option>
                <?php endforeach; ?>
              </select></td>
            <td data-label="<?= h(t('Aktív')) ?>"><label class="check"><input form="uf<?= (int)$us['id'] ?>" type="checkbox" name="is_active" <?= $us['is_active'] ? 'checked' : '' ?>></label></td>
            <td class="nowrap muted" data-label="<?= h(t('Utolsó belépés')) ?>"><?= h(substr((string)($us['last_login_at'] ?? '—'), 0, 16)) ?></td>
            <td class="nowrap" data-label="">
              <button class="btn btn--sm btn--p" form="uf<?= (int)$us['id'] ?>" type="submit"><?= h(t('Mentés')) ?></button>
              <button class="btn btn--sm" type="button" data-modal="pw<?= (int)$us['id'] ?>"><?= h(t('Jelszó')) ?></button>
              <?php if ((int)$us['id'] !== (int)$me['id']): ?>
                <form method="post" action="<?= h(admin_url()) ?>" style="display:inline"
                      data-confirm="<?= h(t('Véglegesen törlöd ezt a felhasználót?')) ?>">
                  <?= csrf_input() ?>
                  <input type="hidden" name="a" value="user.delete">
                  <input type="hidden" name="id" value="<?= (int)$us['id'] ?>">
                  <button class="btn btn--sm btn--danger" type="submit"><?= h(t('Törlés')) ?></button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php foreach ($users as $us): ?>
  <div class="modal" id="modal-pw<?= (int)$us['id'] ?>">
    <div class="modal__box">
      <form method="post" action="<?= h(admin_url()) ?>" autocomplete="off">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="user.resetpw">
        <input type="hidden" name="id" value="<?= (int)$us['id'] ?>">
        <div class="modal__h">Jelszó beállítása — <?= h($us['username']) ?></div>
        <div class="modal__b">
          <div class="field"><label><?= h(t('Új jelszó')) ?></label>
            <input class="inp" name="password" type="password" required minlength="8">
            <div class="hint"><?= h(t('A felhasználónak az első belépéskor cserélnie kell.')) ?></div></div>
        </div>
        <div class="modal__f">
          <button class="btn btn--ghost" type="button" data-close><?= h(t('Mégsem')) ?></button>
          <button class="btn btn--p" type="submit"><?= h(t('Beállítás')) ?></button>
        </div>
      </form>
    </div>
  </div>
<?php endforeach; ?>
    <?php
    admin_foot();
}

// ============================================================ BEÁLLÍTÁSOK
/**
 * A "Beallitasok" szetbontva: minden temanak sajat lapja van.
 *
 * Egyetlen hosszu Beallitasok lapon egymas alatt allt a gepi fordito, a
 * nyelvek, a kiadasok, a felulet szovegei, a sajat jelszo es az oldalcimek -
 * ot-hat, egymashoz semmi kozuk. Mostantol a fogaskerek egy MENUT nyit, es
 * mindegyik onallo lap. Ket panel pedig oda kerult, ahova tartozik:
 *   - a sajat jelszo a Sajat fiok lapra
 *   - az oldalcimek a Forditas lapra (azok is nyelvenkenti szovegek)
 */
function page_mt(PDO $db, array $cfg, array $counts): void
{
    $tr = Translator::fromConfig($cfg, $db);
    $envMt = ($cfg['mt_provider'] ?? '') !== '';

    admin_head(t('Gépi fordítás'), 'settings', $counts);
    ?>
<div class="page" style="max-width:900px">
  <h1 class="pt"><?= h(t('Gépi fordítás')) ?></h1>
  <?= flash_render() ?>
  <div class="panel" style="margin-bottom:16px">
 <div class="panel__h"><h2><?= h(t('Gépi fordítás')) ?></h2><span class="sp"></span>
      <span class="badge <?= $tr->isConfigured() ? 'badge--ok' : '' ?>"><?= h($tr->label()) ?></span></div>
    <div class="panel__b">
      <?php if ($envMt): ?>
        <div class="msg msg--info">A fordító <b><?= h(t('környezeti változóból')) ?></b> jön (HELP_MT_PROVIDER), ezért az itteni
          beállítás nem érvényesül. Ha itt akarod állítani, vedd ki a környezeti változót.</div>
      <?php endif; ?>
      <form method="post" action="<?= h(admin_url()) ?>" autocomplete="off">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="setting.save">
        <div class="row">
          <div class="field" style="flex:0 1 200px"><label><?= h(t('Szolgáltató')) ?></label>
            <select class="sel" name="mt_provider">
              <?php foreach (['none' => 'nincs (kézi fordítás)', 'claude' => 'Claude (Anthropic)',
                              'deepl' => 'DeepL', 'libre' => 'LibreTranslate', 'google' => 'Google Translate'] as $k => $v): ?>
                <option value="<?= h($k) ?>" <?= admin_setting($db, 'mt_provider', 'none') === $k ? 'selected' : '' ?>><?= h($v) ?></option>
              <?php endforeach; ?>
            </select></div>
          <div class="field"><label><?= h(t('Végpont (LibreTranslate-nél kötelező)')) ?></label>
            <input class="inp mono" name="mt_endpoint" value="<?= h(admin_setting($db, 'mt_endpoint')) ?>" placeholder="https://libretranslate.example.com"></div>
          <div class="field"><label><?= h(t('API-kulcs')) ?></label>
            <input class="inp mono" name="mt_key" type="password"
                   value="<?= admin_setting($db, 'mt_key') !== '' ? '********' : '' ?>"
                   placeholder="<?= admin_setting($db, 'mt_key') !== '' ? t('beállítva') : t('nincs beállítva') ?>">
            <div class="hint"><?= h(t('Ha nem módosítod, a mostani kulcs marad érvényben.')) ?></div></div>
        </div>
        <div class="field" style="margin-top:10px">
          <label>Szakszótár <span class="muted"><?= h(t('(a Claude ezt utasításként kapja meg)')) ?></span></label>
          <textarea class="ta" name="mt_glossary" rows="6"
                    placeholder="<?= h(t('kintlévőség kezelés = receivables management / Forderungsmanagement&#10;bizonylatlánc = document chain / Belegkette&#10;áfa adóalany = VAT taxable person / umsatzsteuerpflichtige Person')) ?>"><?= h(admin_setting($db, 'mt_glossary')) ?></textarea>
          <div class="hint">Soronként egy kifejezés. Bal oldalon a magyar, jobb oldalon az, ahogy
            fordítani kell. Ez az, ami a szótárazó fordítókból hiányzik — tőlük a
            <b><?= h(t('„kintlévőség kezelés"')) ?></b> könnyen <b>„capacity management"</b> lesz.</div>
        </div>

        <div class="field" style="margin-top:6px">
          <label class="check">
            <input type="checkbox" name="mt_auto" value="1" <?= admin_setting($db, 'mt_auto', '0') === '1' ? 'checked' : '' ?>>
            <b><?= h(t('Automatikus fordítás:')) ?></b> ha egy magyar fejezetet közzéteszel, illetve Word-ből
            importálsz, rögtön készüljön belőle angol és német vázlat is
          </label>
          <div class="hint">A gépi fordítás mindig csak <b><?= h(t('vázlatot')) ?></b> készít — közzétenni ember dönt.
            Szolgáltató nélkül ez a kapcsoló hatástalan.</div>
        </div>
        <button class="btn btn--p" type="submit"><?= h(t('Mentés')) ?></button>
      </form>

      <div class="hint" style="margin-top:12px">
        Fizetős kulcs nélkül is megoldható: a csomagban van egy <b><?= h(t('saját, helyben futó')) ?></b> fordító
        (LibreTranslate) — <span class="mono">docker compose --profile mt up -d</span>, majd
        Szolgáltató = LibreTranslate, Végpont = <span class="mono">http://libretranslate:5000</span>.
        <br>
        A fordítás HTML-ként megy át a szolgáltatóhoz (DeepL: <span class="mono">tag_handling=html</span>),
        így a formázás és a képek a helyükön maradnak. Gépi fordító nélkül is használható a Fordítás fül,
        csak a nyersfordítás gomb marad inaktív.
      </div>
    </div>
  </div>
</div>
    <?php
    admin_foot();
}

function page_langs(PDO $db, array $cfg, array $counts): void
{
    $langs = [];
    try {
        $langs = $db->query('SELECT * FROM help_lang ORDER BY is_source DESC, sort_order, code')->fetchAll();
    } catch (Throwable $e) {
        // a 07_nyelvek.sql meg nem futott le
    }

    admin_head(t('Nyelvek'), 'settings', $counts);
    ?>
<div class="page" style="max-width:900px">
  <h1 class="pt"><?= h(t('Nyelvek')) ?></h1>
  <?= flash_render() ?>
  <div class="panel" style="margin-bottom:16px">
    <div class="panel__h"><h2><?= h(t('Nyelvek')) ?></h2><span class="sp"></span>
      <span class="badge"><?= count($langs) ?></span></div>
    <div class="panel__b">
      <p class="lead" style="margin-bottom:12px">
        A súgó nyelvei. Az elsőt <b><?= h(t('forrásnyelvnek')) ?></b> hívjuk: ezen írod a fejezeteket,
        és ebből készül a fordítás. Új nyelv felvételéhez nem kell fejlesztő —
        a felvétel után rögtön megjelenik a Fordítás fülön és a nyilvános oldalon.
      </p>

      <table class="tbl">
        <thead><tr><th><?= h(t('Kód')) ?></th><th><?= h(t('Név')) ?></th><th><?= h(t('Saját neve')) ?></th><th><?= h(t('Sorrend')) ?></th><th><?= h(t('Aktív')) ?></th><th></th></tr></thead>
        <tbody>
        <?php foreach ($langs as $l): ?>
          <tr>
            <form method="post" action="<?= h(admin_url()) ?>">
              <?= csrf_input() ?>
              <input type="hidden" name="a" value="lang.save">
              <input type="hidden" name="code" value="<?= h($l['code']) ?>">
              <td data-label="<?= h(t('Kód')) ?>">
                <b class="mono"><?= h($l['code']) ?></b>
                <?php if ((int)$l['is_source']): ?>
                  <span class="badge badge--ok"><?= h(t('forrás')) ?></span>
                <?php endif; ?>
              </td>
              <td data-label="<?= h(t('Név')) ?>"><input class="inp" name="name" value="<?= h($l['name']) ?>" required></td>
              <td data-label="<?= h(t('Saját neve')) ?>"><input class="inp" name="own_name" value="<?= h((string)$l['own_name']) ?>"
                     placeholder="<?= h(t('ahogy azon a nyelven hívják')) ?>"></td>
              <td data-label="Sorrend" style="width:110px">
                <input class="inp" name="sort_order" type="number" value="<?= (int)$l['sort_order'] ?>"></td>
              <td data-label="<?= h(t('Aktív')) ?>">
                <?php if ((int)$l['is_source']): ?>
                  <span class="muted">mindig</span>
                <?php else: ?>
                  <label class="check"><input type="checkbox" name="is_active" value="1"
                         <?= (int)$l['is_active'] ? 'checked' : '' ?>> <?= h(t('látszik')) ?></label>
                <?php endif; ?>
              </td>
              <td class="nowrap" data-label="">
                <button class="btn btn--sm" type="submit"><?= h(t('Mentés')) ?></button>
              </td>
            </form>
            <?php if (!(int)$l['is_source']): ?>
              <td class="nowrap" style="padding-left:0">
                <form method="post" action="<?= h(admin_url()) ?>"
                      data-confirm="<?= h(t('torles.nyelv', ['nev' => (string)$l['name']])) ?>">
                  <?= csrf_input() ?>
                  <input type="hidden" name="a" value="lang.delete">
                  <input type="hidden" name="code" value="<?= h($l['code']) ?>">
                  <button class="btn btn--sm btn--danger" type="submit"><?= h(t('Törlés')) ?></button>
                </form>
              </td>
            <?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>

      <form method="post" action="<?= h(admin_url()) ?>" style="margin-top:14px">
        <?= csrf_input() ?>
        <input type="hidden" name="a" value="lang.add">
        <div class="lbl"><?= h(t('Új nyelv')) ?></div>
        <div class="row">
          <div class="field" style="flex:0 1 110px"><label><?= h(t('Kód')) ?></label>
            <input class="inp mono" name="code" placeholder="sk" maxlength="5" required>
            <div class="hint"><?= h(t('két betű (ISO)')) ?></div></div>
          <div class="field"><label><?= h(t('Név (magyarul)')) ?></label>
            <input class="inp" name="name" placeholder="<?= h(t('Szlovák')) ?>" required></div>
          <div class="field"><label><?= h(t('Saját neve')) ?></label>
            <input class="inp" name="own_name" placeholder="Slovenčina"></div>
          <div class="field" style="flex:0 1 auto;align-self:flex-end">
            <button class="btn btn--p" type="submit"><?= h(t('Nyelv hozzáadása')) ?></button></div>
        </div>
        <div class="hint"><?= t('A felvételkor a főfejezetek átmásolódnak az új nyelvre (magyar névvel, amit utána a Fejezetek fülön írhatsz át), hogy legyen hova tenni a fordításokat.') ?></div>
      </form>
    </div>
  </div>
</div>
    <?php
    admin_foot();
}

// ============================================================ KUKA
function page_trash(PDO $db, array $counts): void
{
    $rows = $db->query("
        SELECT t.*, u.display_name
          FROM help_trash t LEFT JOIN help_user u ON u.id = t.deleted_by
      ORDER BY t.restored_at IS NOT NULL, t.deleted_at DESC
         LIMIT 200")->fetchAll();
    $open = array_filter($rows, static fn($r) => $r['restored_at'] === null);

    admin_head('Kuka', 'trash', $counts);
    ?>
<div class="page" style="max-width:1100px">
  <h1 class="pt"><?= h(t('Kuka')) ?></h1>
  <p class="lead"><?= t('A törölt fejezetek és modulok <b>nem vesznek el</b>: teljes tartalmukkal ide kerülnek — a szakaszaikkal, a verziótörténetükkel és a képernyő-hozzárendeléseikkel együtt —, és egy kattintással visszaállíthatók. Véglegesen csak innen törlődnek.') ?></p>
  <?= flash_render() ?>

  <div class="panel">
 <div class="panel__h"><h2><?= h(t('Törölt elemek')) ?></h2><span class="sp"></span>
      <span class="badge <?= $open ? 'badge--warn' : '' ?>"><?= count($open) ?> <?= h(t('visszaállítható')) ?></span>
      <?php if ($open): ?>
        <form method="post" action="<?= h(admin_url()) ?>"
              data-confirm="<?= h(t('Véglegesen törlöd a Kuka teljes tartalmát? Ez nem vonható vissza.')) ?>">
          <?= csrf_input() ?>
          <input type="hidden" name="a" value="trash.purge">
          <input type="hidden" name="id" value="0">
          <button class="btn btn--sm btn--danger" type="submit"><?= h(t('Kuka ürítése')) ?></button>
        </form>
      <?php endif; ?>
    </div>
    <div class="panel__b panel__b--flush">
      <?php if (!$rows): ?>
        <div class="empty"><?= h(t('A Kuka üres.')) ?></div>
      <?php else: ?>
        <table class="tbl">
          <thead><tr><th><?= h(t('Mit')) ?></th><th><?= h(t('Megnevezés')) ?></th><th><?= h(t('Nyelv')) ?></th><th><?= h(t('Mikor')) ?></th><th><?= h(t('Ki')) ?></th><th></th></tr></thead>
          <tbody>
          <?php foreach ($rows as $r):
              $kind = match ($r['kind']) {
                  'article' => 'fejezet', 'module' => 'modul', 'move' => 'áthelyezés', default => $r['kind'],
              }; ?>
            <tr<?= $r['restored_at'] !== null ? ' style="opacity:.55"' : '' ?>>
              <td data-label="Mit"><span class="badge"><?= h($kind) ?></span></td>
              <td data-label="<?= h(t('Megnevezés')) ?>"><b><?= h($r['label']) ?></b></td>
              <td data-label="Nyelv" class="mono"><?= h((string)$r['lang']) ?></td>
              <td data-label="Mikor" class="nowrap muted"><?= h(substr((string)$r['deleted_at'], 0, 16)) ?></td>
              <td data-label="Ki" class="muted"><?= h((string)$r['display_name']) ?></td>
              <td data-label="" class="nowrap">
                <?php if ($r['restored_at'] !== null): ?>
                  <span class="badge badge--ok"><?= h(t('visszaállítva')) ?></span>
                <?php else: ?>
                  <form method="post" action="<?= h(admin_url()) ?>" style="display:inline">
                    <?= csrf_input() ?>
                    <input type="hidden" name="a" value="trash.restore">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn--sm btn--p" type="submit"><?= h(t('↩ Visszaállítás')) ?></button>
                  </form>
                  <form method="post" action="<?= h(admin_url()) ?>" style="display:inline"
                        data-confirm="<?= h(t('Véglegesen törlöd? Ez nem vonható vissza.')) ?>">
                    <?= csrf_input() ?>
                    <input type="hidden" name="a" value="trash.purge">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn--sm btn--danger" type="submit"><?= h(t('Végleges törlés')) ?></button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
</div>
    <?php
    admin_foot();
}

/**
 * A parancspaletta (Ctrl+K) talalatai: fulek, muveletek es fejezetek egyben.
 * @return list<array{group:string,label:string,sub:string,url:string,key:string}>
 */
function palette_items(PDO $db, string $q): array
{
    $q = trim($q);
    $out = [];

    // 1. fulek es gyorsmuveletek
    $nav = [
        [t('Áttekintés'), 'dashboard', t('Vázlatok, statisztika, napló')],
        [t('Fejezetek'), 'articles', t('Szerkesztés, közzététel, verziók')],
        [t('Modulok'), 'modules', t('A súgó felső szintje')],
        [t('Word import'), 'import', t('.docx betöltése összehasonlítással')],
        [t('Fordítás'), 'translate', t('HU → EN/DE')],
        [t('Képernyők'), 'screens', t('Útvonal → fejezet')],
        [t('Képek, videók'), 'media', t('Fájltár, feltöltés')],
        [t('Export'), 'export', t('Word / PDF letöltés')],
        [t('Felhasználók'), 'users', t('Fiókok, szerepkörök')],
        [t('Kuka'), 'trash', t('Törölt elemek visszaállítása')],
        [t('Beállítások'), 'settings', t('Fordító, kiadás, oldalcímek')],
        [t('Saját fiók'), 'account', t('Jelszócsere')],
    ];
    foreach ($nav as [$label, $page, $sub]) {
        if (!auth_can($page) && !in_array($page, ['account'], true)) { continue; }
        if ($q === '' || mb_stripos(help_norm($label . ' ' . $sub), help_norm($q)) !== false) {
            $out[] = ['group' => t('Menü'), 'label' => $label, 'sub' => $sub,
                      'url' => admin_url(['p' => $page]), 'key' => 'p-' . $page];
        }
    }

    // 2. fejezetek
    if ($q !== '' && auth_can('articles')) {
        // az ekezet-fuggetlenseget a tabla utf8mb4_uca1400_ai_ci rendezese adja
        $st = $db->prepare("
            SELECT a.id, a.lang, a.chapter_no, a.title, a.is_published,
                   a.draft_html IS NOT NULL AS has_draft, m.title AS module_title
              FROM help_article a LEFT JOIN help_module m ON m.id = a.module_id
             WHERE CONCAT(a.chapter_no, ' ', a.title) LIKE ?
          ORDER BY (a.lang = 'hu') DESC, a.sort_order
             LIMIT 25");
        $st->execute(['%' . $q . '%']);
        foreach ($st->fetchAll() as $r) {
            $flags = [];
            if ($r['has_draft'])     { $flags[] = t('vázlat'); }
            if (!$r['is_published']) { $flags[] = 'kikapcsolva'; }
            $out[] = [
                'group' => 'Fejezet',
                'label' => trim($r['chapter_no'] . ' ' . $r['title']),
                'sub'   => strtoupper((string)$r['lang']) . ' · ' . (string)$r['module_title']
                         . ($flags ? ' · ' . implode(', ', $flags) : ''),
                'url'   => admin_url(['p' => 'articles', 'lang' => $r['lang'], 'id' => $r['id']]),
                'key'   => 'a-' . $r['id'],
            ];
        }
    }

    return array_slice($out, 0, 40);
}
