<?php
/**
 * admin.php - az Infinity Súgó szerkesztői és adminisztrációs felülete.
 *
 *   /admin.php                 -> Áttekintés (bejelentkezés után)
 *   /admin.php?p=articles      -> Fejezetek szerkesztése, közzététel, verziók
 *   /admin.php?p=modules       -> Modulok
 *   /admin.php?p=import        -> Word (.docx) betöltés összehasonlítással
 *   /admin.php?p=translate     -> Fordítás (HU -> EN/DE), gépi nyersfordítással
 *   /admin.php?p=screens       -> Képernyő -> fejezet hozzárendelés
 *   /admin.php?p=media         -> Képek
 *   /admin.php?p=users         -> Felhasználók
 *   /admin.php?p=settings      -> Beállítások, kiadás lezárása
 *
 * Az elso belepes: admin / 12345678 - utana a rendszer kotelezoen jelszot cserel.
 */
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

require __DIR__ . '/lib/util.php';
require __DIR__ . '/lib/auth.php';
require __DIR__ . '/lib/diff.php';
require __DIR__ . '/lib/docx.php';
require __DIR__ . '/lib/mt.php';
require __DIR__ . '/lib/media.php';
require __DIR__ . '/lib/docx_export.php';
require __DIR__ . '/lib/trash.php';
require __DIR__ . '/lib/admin_layout.php';
require __DIR__ . '/lib/admin_i18n.php';
require __DIR__ . '/lib/admin_editor.php';
require __DIR__ . '/lib/admin_releases.php';
require __DIR__ . '/lib/admin_actions.php';
require __DIR__ . '/lib/admin_pages.php';
require __DIR__ . '/lib/admin_pages2.php';
require __DIR__ . '/lib/admin_uitexts.php';

$cfg = require __DIR__ . '/config.php';
auth_start($cfg);

header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header('X-Content-Type-Options: nosniff');

try {
    $db = help_db_rw($cfg);
} catch (PDOException $e) {
    http_response_code(503);
    admin_head('Adatbázishiba');
    echo '<div class="page" style="max-width:640px"><div class="msg msg--err">'
       . '<b>Az adatbázis nem érhető el.</b> Az admin felület írás-olvasás jogú kapcsolatot használ '
       . '(alapértelmezés szerint a <span class="mono">help_rw</span> felhasználót). Ellenőrizd a '
       . '<span class="mono">HELP_DB_ADMIN_USER</span> / <span class="mono">HELP_DB_ADMIN_PASS</span> beállítást.'
       . '</div></div>';
    admin_foot();
    exit;
}

// ------------------------------------------------------------ kijelentkezés
if (($_GET['a'] ?? '') === 'logout') {
    $u = auth_user();
    if ($u) { audit($db, (int)$u['id'], $u['username'], 'logout'); }
    auth_logout();
    auth_start($cfg);
    flash('ok', 'Kiléptél.');
    header('Location: ' . admin_url(['p' => 'login']), true, 303);
    exit;
}

// ------------------------------------------------------------ írási műveletek
$action = (string)($_POST['a'] ?? '');
if ($action !== '') {
    // a bejelentkezésen kívül mindenhez kell élő munkamenet
    if ($action !== 'login' && auth_user() === null) {
        flash('err', 'A munkamenet lejárt, jelentkezz be újra.');
        header('Location: ' . admin_url(['p' => 'login']), true, 303);
        exit;
    }
    admin_handle_action($action, $db, $cfg);
    exit;
}

// ------------------------------------------------------------ nyomtatható / PDF export
// Szandekosan GET: igy uj lapon nyilik, ujratoltheto, es nem kell "urlap
// ujrakuldese" parbeszed. Csak olvas, elo munkamenetet igenyel.
if (($_GET['a'] ?? '') === 'export.html') {
    if (auth_user() === null) {
        header('Location: ' . admin_url(['p' => 'login']), true, 303);
        exit;
    }
    if (!auth_can('export')) {
        http_response_code(403);
        echo 'Nincs jogosultság az exporthoz.';
        exit;
    }
    $expLang = array_key_exists((string)($_GET['lang'] ?? ''), admin_langs()) ? (string)$_GET['lang'] : 'hu';
    $html = export_print_html($db, $cfg, $expLang, !isset($_GET['include_hidden']), isset($_GET['print']));
    audit_me($db, 'export.html', $expLang);

    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    echo $html;
    exit;
}

// ------------------------------------------------------------ parancspaletta keresője
if (($_GET['a'] ?? '') === 'palette') {
    if (auth_user() === null) { help_json(['items' => []], 401); }
    help_json(['items' => palette_items($db, (string)($_GET['q'] ?? ''))]);
}

// ------------------------------------------------------------ megjelenítés
$user = auth_user();
if ($user === null) {
    page_login();
    exit;
}
// A jelszocsere NEM kotelezo belepeskor - a Beallitasok / Sajat fiok lapon
// barmikor elvegezheto. Ha meg a kezdojelszo van ervenyben, csak emlekeztetunk ra.
if ($user['must_change'] && ($_GET['p'] ?? '') === '') {
    flash('warn', 'Még a kezdeti jelszó van érvényben. '
        . 'Ha szeretnéd lecserélni: <a href="' . h(admin_url(['p' => 'settings'])) . '#jelszo">Beállítások → Jelszó</a>.');
    $_SESSION['user']['must_change'] = false;   // egyszer szoljunk, ne minden betoltesnel
}

$page = (string)($_GET['p'] ?? 'dashboard');
$lang = array_key_exists((string)($_GET['lang'] ?? ''), admin_langs()) ? (string)$_GET['lang'] : 'hu';

// a füleken megjelenő számok
$counts = [];
try {
    $c = $db->query("
        SELECT (SELECT count(*) FROM help_article WHERE draft_html IS NOT NULL) AS drafts,
               (SELECT count(*) FROM help_article WHERE lang = 'hu')            AS articles,
               (SELECT count(*) FROM help_module  WHERE lang = 'hu')            AS modules,
               (SELECT count(*) FROM help_screen_map)                           AS screens,
               (SELECT count(*) FROM help_user WHERE is_active)                 AS users
    ")->fetch();
    $counts = [
        'articles' => (int)$c['articles'],
        'modules'  => (int)$c['modules'],
        'screens'  => (int)$c['screens'],
        'users'    => (int)$c['users'],
    ];
    if ((int)$c['drafts'] > 0) { $counts['dashboard'] = (int)$c['drafts']; }
} catch (Throwable $e) {
    // a fulszamok hianya ne akassza meg a lapot
}

if ($page === 'chpw')    { page_chpw((bool)$user['must_change']); exit; }
if ($page === 'account') { page_account($db); exit; }

if (!auth_can($page) && $page !== 'dashboard') {
    http_response_code(403);
    admin_head('Nincs jogosultság', '', $counts);
    echo '<div class="page"><div class="msg msg--err"><b>Ehhez a felülethez nincs jogosultságod.</b> '
       . 'A szerepköröd: <b>' . h($user['role']) . '</b>.</div></div>';
    admin_foot();
    exit;
}

switch ($page) {
    case 'articles':
        page_articles($db, $lang, (int)($_GET['id'] ?? 0), $counts, (int)($_GET['mod'] ?? 0),
                      (int)($_GET['diff'] ?? 0));
        break;
    case 'modules':
        // A Modulok ful beolvadt a Fejezetek fulbe: a fofejezetek ott
        // szerkeszthetok, huzhatok, hozhatok letre es torolhetok.
        header('Location: ' . admin_url(['p' => 'articles', 'lang' => $lang]), true, 302);
        exit;
    case 'import':
        page_import($db, $cfg, $lang, (int)($_GET['import'] ?? 0), $counts);
        break;
    case 'translate':
        page_translate($db, $cfg, (int)($_GET['src'] ?? 0), (string)($_GET['to'] ?? 'en'), $counts,
                       (string)($_GET['st'] ?? 'all'),
                       (string)($_GET['l'] ?? ''), (string)($_GET['r'] ?? ''));
        break;
    case 'screens':
        // A "?" gomb kepernyo -> fejezet hozzarendelese. A sugo kulon oldalkent
        // mukodik, nincs beepitve az Infinitybe, ezert a ful nem latszik; a lap
        // maga megmaradt, ha kesobb megis kell.
        page_screens($db, $counts);
        break;
    case 'media':
        page_media($db, $cfg, (int)($_GET['page'] ?? 1), $counts);
        break;
    case 'users':
        page_users($db, $counts);
        break;
    case 'releases':
        page_releases($db, $counts, (int)($_GET['rel'] ?? 0));
        break;
    case 'export':
        page_export($db, $cfg, $lang, $counts);
        break;
    case 'trash':
        page_trash($db, $counts);
        break;
    // A "Beallitasok" szetesett: minden temanak sajat lapja van, a
    // fogaskerek pedig menut nyit. A regi ?p=settings a gepi forditasra
    // visz, hogy a konyvjelzok es a regi hivatkozasok ne torjenek el.
    case 'settings':
    case 'mt':
        page_mt($db, $cfg, $counts);
        break;
    case 'langs':
        page_langs($db, $cfg, $counts);
        break;
    case 'uitexts':
        page_uitexts($db, $cfg, $counts);
        break;
    default:
        page_dashboard($db, $cfg, $counts);
}
